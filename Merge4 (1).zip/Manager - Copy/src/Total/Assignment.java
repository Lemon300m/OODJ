package Total;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author deracho
 */
public class Assignment {

    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
    }
}


